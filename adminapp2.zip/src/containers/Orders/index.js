import React from 'react';
import Layout from '../../components/Layout';
function Orders(props) {
  return (
<Layout sidebar>Orders</Layout>
  )
}

export default Orders;